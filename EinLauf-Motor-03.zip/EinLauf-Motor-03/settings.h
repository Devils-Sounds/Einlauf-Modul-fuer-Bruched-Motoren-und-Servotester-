#pragma once

// ---------------------------------------
// SERVO GRUNDEINSTELLUNGEN
// ---------------------------------------
const int SERVO_NEUTRAL = 1500;
const int SERVO_QUARTER = 1600;
const int SERVO_HALF    = 1750;
const int SERVO_FULL    = 2000;

// Rampen-Geschwindigkeit
const int SERVO_STEP = 3;                  // Puls-Schrittweite
const unsigned long STEP_INTERVAL_MS = 15; // Zeit pro Schritt (ms)


// ---------------------------------------
// SERVO FUNKTION – Laufzeit
// ---------------------------------------
const float SERVO_FUNC_MINUTES = 3.0;      // Servo Test Dauer (Minuten)


// ---------------------------------------
// EINLAUF DYN – Einstellungen
// ---------------------------------------
const int EINLAUF_DYN_MINUTES    = 2;     // Dauer eines Durchlaufs
const uint8_t EINLAUF_DYN_REPEATS = 5;     // Anzahl Wiederholungen


// ---------------------------------------
// EINLAUF PROGRAMME (alle 7 Phasen)
// Jede Phase: Start-Puls, End-Puls, Haltezeit (ms)
// + Anzahl der kompletten Zyklen
// ---------------------------------------

// ---------- 1) STANDARD ----------
const uint8_t EINLAUF_STD_CYCLES = 8;

const unsigned long PHASE_TIME_STD[7] = {
  2000,   // Phase 0
  2000,   // Phase 1
  1500,   // Phase 2
  2000,   // Phase 3
  2000,   // Phase 4
  2500,   // Phase 5
  500     // Phase 6
};

const int PHASE_START_STD[7] = {
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_FULL
};

const int PHASE_END_STD[7] = {
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_FULL,
  SERVO_NEUTRAL
};


// ---------- 2) SICHER (SAFE) ----------
const uint8_t EINLAUF_SAFE_CYCLES = 4;

const unsigned long PHASE_TIME_SAFE[7] = {
  3000,  // sanft anfahren
  5000,
  4000,
  5000,
  3000,
  6000,  // etwas längere Last, aber nicht Vollgas
  1500
};

const int PHASE_START_SAFE[7] = {
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_NEUTRAL
};

const int PHASE_END_SAFE[7] = {
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_HALF,
  1900,           // knapp unter Vollgas
  SERVO_NEUTRAL
};


// ---------- 3) POWER ----------
const uint8_t EINLAUF_POWER_CYCLES = 8;

const unsigned long PHASE_TIME_POWER[7] = {
  2000,
  3000,
  2000,
  4000,
  3000,
  8000,   // Vollgas länger halten, aber nicht extrem
  1000
};

const int PHASE_START_POWER[7] = {
  SERVO_NEUTRAL,
  1650,
  1800,
  SERVO_NEUTRAL,
  1700,
  1900,
  SERVO_NEUTRAL
};

const int PHASE_END_POWER[7] = {
  1650,
  1800,
  SERVO_NEUTRAL,
  1700,
  1900,
  SERVO_FULL,
  SERVO_NEUTRAL
};


// ---------- 4) REALDRIVE ----------
const uint8_t EINLAUF_REAL_CYCLES = 10;

const unsigned long PHASE_TIME_REAL[7] = {
  1500,  // leicht anrollen
  3500,  // beschleunigen
  1000,  // kurz vom Gas
  5000,  // etwas „Vollgas-Fahrt“
  1000,  // bremsen
  2500,  // Teillast
  500    // zurück in Neutral
};

const int PHASE_START_REAL[7] = {
  SERVO_NEUTRAL,
  SERVO_QUARTER,
  SERVO_NEUTRAL,
  SERVO_HALF,
  SERVO_NEUTRAL,
  1850,
  SERVO_NEUTRAL
};

const int PHASE_END_REAL[7] = {
  SERVO_QUARTER,
  SERVO_HALF,
  SERVO_NEUTRAL,
  SERVO_FULL,
  SERVO_NEUTRAL,
  SERVO_HALF,
  SERVO_NEUTRAL
};


// ---------- 5) CRAWLER ----------
const uint8_t EINLAUF_CRAWL_CYCLES = 5;

// Haltezeiten: eher gemütlich, mit deutlicher Vor- UND Rückwärts-Phase
const unsigned long PHASE_TIME_CRAWL[7] = {
  3000,  // leicht vorwärts
  4000,  // Vollgas vorwärts
  2000,  // Neutral
  3000,  // leicht rückwärts
  4000,  // Vollgas rückwärts
  2000,  // zurück nach Neutral
  2000   // kurze Stand-Phase
};

// Start-/Endwerte: neutral (1500), vorwärts (bis 2000), rückwärts (bis 900)
const int PHASE_START_CRAWL[7] = {
  SERVO_NEUTRAL, // 1500 -> 1600
  1600,          // 1600 -> 2000
  SERVO_FULL,    // 2000 -> 1500
  SERVO_NEUTRAL, // 1500 -> 1300
  1300,          // 1300 -> 900
  900,           // 900  -> 1500
  SERVO_NEUTRAL  // 1500 -> 1500 (Stand)
};

const int PHASE_END_CRAWL[7] = {
  1600,          // leicht vor
  SERVO_FULL,    // Vollgas vor
  SERVO_NEUTRAL, // wieder neutral
  1300,          // leicht rück
  900,           // Vollgas rück
  SERVO_NEUTRAL, // zurück neutral
  SERVO_NEUTRAL  // stehen bleiben
};